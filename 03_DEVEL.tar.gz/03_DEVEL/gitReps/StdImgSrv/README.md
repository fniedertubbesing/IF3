# StdImgSrv
Standard Image Server 

Provides the source code of the so called Standard Image Server.
The Makefile can be used for compilation on standard linux software development environment.
Required: openCV and C++ compiler.

The eclipse-projects and environment files are added as well.
